﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net.Mime;

namespace Ques2
{
	internal class Program
	{
		static List<ingredients> items = new List<ingredients>();
		static void Main(string[] args)
		{
			ingredients ingredient1 = new ingredients("Strawberries",1.50);
			items.Add(ingredient1);
			ingredients ingredient2 = new ingredients("Banana",0.50);
			items.Add(ingredient2);
			ingredients ingredient3 = new ingredients("Mango",2.50);
			items.Add(ingredient3);
			ingredients ingredient4 = new ingredients("Blueberries",1.00);
			items.Add(ingredient4);
			ingredients ingredient5 = new ingredients("Raspberries",1.00);
			items.Add(ingredient5);
			ingredients ingredient6 = new ingredients("Apple",1.75);
			items.Add(ingredient6);
			ingredients ingredient7 = new ingredients("Pineapple",3.50);
			items.Add(ingredient7);

			List<string> smoothies = GetSmoothieFromInput();
			Smoothie s = new Smoothie(smoothies);
			outputResult(s);
		}

		public static void outputResult(Smoothie s)
		{

			Console.WriteLine(Math.Round( s.GetCost(), 2));
			Console.WriteLine(Math.Round(s.GetPrice(), 2));
			Console.WriteLine(s.GetName());
		}
		public static List<string> GetSmoothieFromInput()
		{
			int n = int.Parse(Console.ReadLine());
			List<string> ingredients = new List<string>();
			for (int i = 0; i < n; ++i)
			{
				string _params = Console.ReadLine();
				ingredients.Add(_params);
			}
			return ingredients;
		}

		public class Smoothie
		{
			public List<string> Ingredients = new List<string>();
            public Smoothie(List<string> Ingredients)
            {
				// Write Code Here
				this.Ingredients = Ingredients;
            }

			public double GetCost()
			{
				// Write Code Here
				float cost = 0.0F;
				foreach (string ingredient in this.Ingredients)
				{

					if (ingredient == "Strawberries")
					{
						cost += 1.5F;
					}
					else if (ingredient == "Banana")
					{
						cost += 0.5F;
					}
					else if (ingredient == "Mango")
					{
						cost += 2.5F;
					}
					else if (ingredient == "Blueberries")
					{
						cost += 1.0F;
					}
					else  if (ingredient == "Raspberries")
					{
						cost += 1.0F;
					}
					else if (ingredient == "Apple")
					{
						cost += 1.75F;
					}
					else if (ingredient == "Pineapple")
					{
						cost += 3.50F;
					}
				}
				return cost;
			}
			public double GetPrice()
			{
				// Write Code Here
				return GetCost() + (GetCost()*1.50F);
			}
			public string GetName()
			{
				
			// Write Code Here
				if (Ingredients.Count > 1)
				{
					return "Fusion";
				}
				else if (Ingredients[0] == "Strawberries")
				{
					return "Strawberry";
				}
				else if (Ingredients[0] == "Blueberries")
				{
					return "Blueberry";
				}
				else if (Ingredients[0] == "Raspberry")
				{
					return "Raspberry";
				}
				else
				{
					return Ingredients[0];
				}
			}


			
		}
		public class ingredients
		{
			public string name;
			public double price;

            public ingredients(string name, double price)
            {
				// Write Code Here
				this.name = name;
				this.price = price;
            }
        }

		
	}
}
