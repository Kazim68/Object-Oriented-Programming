﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_1.BL
{
    public class Products
    {
        public string name;
        public string category;
        public string country;
        public int quantity;
        public int price;
    }
}
