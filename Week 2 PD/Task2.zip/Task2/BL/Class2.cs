﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2.BL
{
    internal class Enemy
    {
        public int xpos;
        public int ypos;
        public string direction;
    }
}
